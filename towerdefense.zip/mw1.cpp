#include "mw1.h"
#include "ui_mw1.h"
#include"turnpoint.h"
#include <QTime>
#include<QTimer>
#include <map>
#include <iostream>


using namespace std;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);
    loadtowerpost();
    route();

}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,QPixmap(":/pics/background.png"));
    QPainter *p=new QPainter(this);
        _towersetList.at(0).draw(p);
        _towersetList.at(1).draw(p);
        _towersetList.at(2).draw(p);
        _towersetList.at(3).draw(p);
        _towersetList.at(4).draw(p);
        _towersetList.at(5).draw(p);
    foreach(Attacktower *tower,m_towerList)
        tower->draw(&painter);
    foreach(Turnpoint *po,_turnpointlist)
        po->draw(&painter);
}
void MW1::loadtowerpost(){
    QPoint pos[]={
        QPoint(65,35),
        QPoint(65,125),
        QPoint(65,215),
        QPoint(335,35),
        QPoint(335,125),
        QPoint(335,215)
    };
    int len=sizeof(pos)/sizeof(pos[0]);
    for(int i=0;i<len;++i)
        _towersetList.push_back(pos[i]);
}

void MW1::mousePressEvent(QMouseEvent *e){
    QPoint pressPos=e->pos();
    auto it=_towersetList.begin();
    while(it!=_towersetList.end()){
        if(afford()&&it->hasPoint(pressPos)&&!it->hastower()){
            it->settower();
            Attacktower *tower=new Attacktower(it->cPos());
            m_towerList.push_back(tower);
            update();
            break;
        }
        ++it;
    }
}

void MW1::route(){
    Turnpoint *roupoint1=new Turnpoint(QPoint(30,80));
    _turnpointlist.push_back(roupoint1);
    Turnpoint *roupoint2=new Turnpoint(QPoint(370,80));
    _turnpointlist.push_back(roupoint2);
    Turnpoint *roupoint3=new Turnpoint(QPoint(370,170));
    _turnpointlist.push_back(roupoint3);
    Turnpoint *roupoint4=new Turnpoint(QPoint(30,170));
    _turnpointlist.push_back(roupoint4);
    Turnpoint *roupoint5=new Turnpoint(QPoint(30,250));
    _turnpointlist.push_back(roupoint5);
    Turnpoint *roupoint6=new Turnpoint(QPoint(370,250));
    _turnpointlist.push_back(roupoint6);
}

bool MW1::afford()const{
    return true;
}

void MW1::on_pushButton_2_clicked()
{

}
