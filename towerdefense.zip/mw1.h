#ifndef MW1_H
#define MW1_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QTimer>
#include<QList>
#include"towerset.h"
#include"attacktower.h"
#include"turnpoint.h"

namespace Ui {
class MW1;
}

class MW1 : public QMainWindow
{
public:
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *e);
    void mousePressEvent(QMouseEvent *e);
    void loadtowerpost();//��������λ��
    bool afford()const;//ȷ�Ͻ�Ǯ�Ƿ��㹻���ڹ�������
    void route();//�涨��������·��


private slots:
    void on_pushButton_2_clicked();

private:
    Ui::MW1 *ui;
    QTimer *timer;
    QList<Towerset>_towersetList;
    QList<Attacktower *>m_towerList;
    QList<Turnpoint *>_turnpointlist;
};

#endif // MW1_H
