#include<QPoint>
#include<QPixmap>
#include<QObject>
#include"turnpoint.h"
#include"mw1.h"
#include"monster.h"

Monster:: Monster(Turnpoint *beginpos,MW1 *game,const QPixmap &s)
        :QObject(0),m_pos(beginpos->pos()),m_sp(s){
        _hp=40;
        _chp=40;
        _active=false;
        _speed=1.0;
        _rosp=0.0;
        _despoint=beginpos->nextTurnpoint();
        _game=game;

}

