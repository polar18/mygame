#include"attacktower.h"
#include"towerset.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>

const QSize Attacktower::m_fixsize(44,44);
Attacktower::Attacktower(QPoint pos):m_pos(pos){

}
void Attacktower::draw(QPainter *painter){
    painter->save();
    painter->setPen(Qt::white);
    painter->drawEllipse(m_pos,m_range,m_range);
    static const QPoint offsetPoint(-m_fixsize.width()/2,-m_fixsize.height()/2);
    painter->translate(m_pos);
    painter->drawPixmap(offsetPoint,m_s);
    painter->restore();
}
