#ifndef ATTACKTOWER_H
#define ATTACKTOWER_H
#include<QPoint>
#include<QPixmap>
#include<QPainter>

class Attacktower{
public:
    Attacktower(QPoint pos);//���캯��
    void draw(QPainter *painter);
private:
    QPoint m_pos;
    const int m_range=80;
    const int m_hurt=30;
    const int m_rate=1000;
    const QPixmap m_s=QPixmap(":/pics/tower02.png");
    static const QSize m_fixsize;
};
#endif // ATTACKTOWER_H
