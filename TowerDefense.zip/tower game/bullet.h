#ifndef BULLET_H
#define BULLET_H
#include <QPoint>
#include <QObject>
#include <QPixmap>
#include <QSize>

class QPainter;
class Monster;
class MW1;
class Attacktower;

class Bullet:public QObject{
    Q_OBJECT
    Q_PROPERTY(QPoint m_nowpoint READ nowpoint WRITE setnowpoint)

public:
    Bullet(QPoint startpoint,QPoint targetpoint,int hurt,Monster*  monster,MW1*  game,const QPixmap &sprite=QPixmap(":/pics/monster2.png"));
    void draw(QPainter*  painter)const;
    void move();
    void setnowpos(QPoint pos);
    QPoint nowpos()const;

private:
    int m_hurt;
    const  QPoint m_startpoint;
    const  QPoint m_targetpoint;
    QPoint nowpoint;
    QPixmap  m_sprite;
    MW1*  m_game;
    Monster*  m_monster;
    static const QSize m_fixedsize;

private slots:
    void hitenemy();





};
#endif // BULLET_H
