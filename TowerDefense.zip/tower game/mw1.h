#ifndef MW1_H
#define MW1_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QTimer>
#include<QList>
#include"towerset.h"
#include"attacktower.h"
#include"turnpoint.h"
#include"monster.h"
#include"use.h"
#include"bullet.h"
#include"attacktower.h"


namespace Ui {
class MW1;
class Monster;
class Turnpoint;
class Bullet;
class Attacktower;
}
class MW1 : public QMainWindow
{
    Q_OBJECT
public:
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *e);
    void mousePressEvent(QMouseEvent *e);
    void loadtowerpost();//��������λ��
    bool afford()const;//ȷ�Ͻ�Ǯ�Ƿ��㹻���ڹ�������
    void route();//�涨��������·��
    void drawwave(QPainter* painter);
    void drawhp(QPainter* painter);
    void drawmoney(QPainter* painter);
    void gethurt(int hurt=1);//�����ܵ��˺�
    void removemon(Monster *monster);
    void removebullet(Bullet *bullet);
    void addbullet(Bullet* bullet);
    void getmonney(int money);
    void gameover();
    void prewave();
    QList<Monster *>monsterlist()const;
    bool load();
    QList<Towerset>_towersetList;
    QList<Attacktower *>m_towerList;
    QList<Turnpoint *>_turnpointlist;
    QList<Monster *>_enemyList;
    QList<Bullet *>_bulletList;
   // QList<QVariant> m_wavesinfo;
public slots:
    void updateMap();
    void gamestart();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::MW1 *ui;
    QTimer *timer;
    int m_wave;
    int m_hp;
    int m_money;
    bool m_gameWin;
    bool m_gameEnd;
};

#endif // MW1_H
