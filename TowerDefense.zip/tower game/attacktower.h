#ifndef ATTACKTOWER_H
#define ATTACKTOWER_H
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include<QSize>
#include<QObject>

class QPainter;
class Monster;
class MW1;
class QTimer;

class Attacktower:public QObject{
    Q_OBJECT
public:
    Attacktower(QPoint pos,MW1* game,const QPixmap &s);//���캯��
    ~Attacktower();
    void draw(QPainter *painter)const;
    void checkmonster();
    void choosemonster(Monster  *monster);
    void attackenemy();
    void damageenemy();
    void killed();
    void removebullet();
    void lostenemy();


private:

    const int m_range=150;
    const int m_hurt=20;
    const int m_rate=1000;
    bool  m_attacking;
    qreal m_rotationSprite;

    Monster *  m_chooseEnemy;
    MW1 *	m_game;
    QTimer *	m_fireTimer;

    const QPoint	m_pos;
    const QPixmap m_s=QPixmap(":/pics/sun.png");
    static const QSize m_fixsize;


private slots:
    void shootWeapon();
};
#endif // ATTACKTOWER_H
