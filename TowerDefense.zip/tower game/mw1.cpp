#include "mw1.h"
#include "ui_mw1.h"
#include"turnpoint.h"
#include"monster.h"
#include"attacktower.h"
#include"towerset.h"
#include"bullet.h"
#include <QTime>
#include<QTimer>
#include <map>
#include <iostream>
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QXmlStreamReader>
#include <QtDebug>


using namespace std;


MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
    ,m_wave(0)
    ,m_gameWin(false)
    ,m_gameEnd(false)
    ,m_hp(5)
    ,m_money(600)
{
    ui->setupUi(this);
    loadtowerpost();
    route();

    QTimer *timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(updateMap()));
    timer->start(30);

    QTimer::singleShot(200,this,SLOT(gamestart()));

}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,QPixmap(":/pics/background.png"));
    QPainter *p=new QPainter(this);
        _towersetList.at(0).draw(p);
        _towersetList.at(1).draw(p);
        _towersetList.at(2).draw(p);
        _towersetList.at(3).draw(p);
        _towersetList.at(4).draw(p);
    foreach(Attacktower *tower,m_towerList)
        tower->draw(&painter);
    foreach(Turnpoint *po,_turnpointlist)
        po->draw(&painter);
    foreach(Monster *ene,_enemyList)
        ene->draw(&painter);
    foreach(Bullet *bu,_bulletList)
        bu->draw(&painter);
    drawhp(&painter);
    drawwave(&painter);
    drawmoney(&painter);
}
void MW1::loadtowerpost(){
    QPoint pos[]={
        QPoint(85,50),
        QPoint(85,435),
        QPoint(370,235),
        QPoint(800,50),
        QPoint(800,435)
    };
    int len=sizeof(pos)/sizeof(pos[0]);
    for(int i=0;i<len;++i)
        _towersetList.push_back(pos[i]);
}

void MW1::mousePressEvent(QMouseEvent *e){
    QPoint pressPos=e->pos();
    auto it=_towersetList.begin();
    while(it!=_towersetList.end()){
        if(afford()&&it->hasPoint(pressPos)&&!it->hastower()){
            it->settower();
            const QPixmap &p=QPixmap(":/pics/sun.png");
            Attacktower *tower=new Attacktower(it->cPos(),this,p);
            m_towerList.push_back(tower);
            update();
            break;
        }
        ++it;
    }
}
bool MW1::afford()const{
    if(m_money>=200)
        return true;
    else
        return false;
}
void MW1::getmonney(int money){
    m_money+=money;
    update();
}
void MW1::drawwave(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->drawText((QRect(30,20,150,40)),QString("wave:%1").arg(m_wave+1));
}
void MW1::drawmoney(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(200,20,320,40),QString("money:%1").arg(m_money));
}
void MW1::drawhp(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(450,20,570,40),QString("hp:%1").arg(m_hp));
}
void MW1::route(){
    Turnpoint *roupoint1=new Turnpoint(QPoint(30,135));
    _turnpointlist.push_back(roupoint1);
    Turnpoint *roupoint2=new Turnpoint(QPoint(835,135));
    _turnpointlist.push_back(roupoint2);
    roupoint2->nextPoint(roupoint1);
    Turnpoint *roupoint3=new Turnpoint(QPoint(835,350));
    _turnpointlist.push_back(roupoint3);
    roupoint3->nextPoint(roupoint2);
    Turnpoint *roupoint4=new Turnpoint(QPoint(30,350));
    _turnpointlist.push_back(roupoint4);
    roupoint4->nextPoint(roupoint3);
    Turnpoint *roupoint5=new Turnpoint(QPoint(30,535));
    _turnpointlist.push_back(roupoint5);
    roupoint5->nextPoint(roupoint4);
    Turnpoint *roupoint6=new Turnpoint(QPoint(835,535));
    _turnpointlist.push_back(roupoint6);
    roupoint6->nextPoint(roupoint5);
}

void MW1::gethurt(int hurt){
    m_hp-=hurt;
    if(m_hp<=0)
        gameover();
}

bool MW1::load(){
    if(m_wave>=5)
        return false;
    Turnpoint *startWayPoint=_turnpointlist.back();
    int enespan[]={100,500,600,1000,3000,6000};
    for(int i=0;i<5;++i)
    {
        Monster *monster=new Monster(startWayPoint,this);
        _enemyList.push_back(monster);
        QTimer::singleShot(enespan[i],monster,SLOT(doAct()));

    }
    return true;
}
void MW1::removemon(Monster *monster){
    Q_ASSERT(monster);
    _enemyList.removeOne(monster);
    delete monster;
    if(_enemyList.empty())
    {
        ++m_wave;
        if(!load())
        {
            m_gameWin=true;
        }
    }
}
void MW1::updateMap(){
    foreach(Monster *monster,_enemyList)
        monster->Move();
    foreach(Attacktower *tower,m_towerList)
        tower->checkmonster();
    update();
}
void MW1::gamestart(){
    load();
}
void MW1::gameover(){
    if(!m_gameEnd){
        m_gameEnd=true;
    }
}
QList <Monster *> MW1::monsterlist() const{
    return _enemyList;
}
void MW1::addbullet(Bullet *bullet){
    Q_ASSERT(bullet);
    _bulletList.push_back(bullet);
}
void MW1::removebullet(Bullet *bullet){
    Q_ASSERT(bullet);
    _bulletList.removeOne(bullet);
    delete bullet;
}
void MW1::on_pushButton_2_clicked()
{

}
