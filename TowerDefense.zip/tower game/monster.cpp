#include<QPoint>
#include<QPixmap>
#include<QObject>
#include<QPainter>
#include<QTimer>
#include<QTime>
#include <QColor>
#include <QDebug>
#include <QMatrix>
#include <QVector2D>
#include <QtMath>
#include"monster.h"
#include"use.h"
#include"mw1.h"
#include"turnpoint.h"
#include"attacktower.h"

const QSize Monster::_fixsize(44,44);

Monster::Monster(Turnpoint *beginpos,MW1 *game,const QPixmap &s)
         :QObject(0)
         ,m_pos(beginpos->pos())
         ,m_sp(s)
         ,_active(false)
         ,_chp(40)
         ,_speed(1.0)
         ,m_rotationSprite(0.0)
         ,_despoint(beginpos->nextTurnpoint())
         ,_game(game)
         {


    }

Monster::~Monster(){
    m_attackedTowersList.clear();
    _despoint=NULL;
    _game=NULL;
}
void Monster::draw(QPainter *painter)const{
    if(!_active)
        return;
    static const int life_bar_width=20;
    painter->save();
    QPoint lifebarpoint=m_pos+QPoint(-life_bar_width/2-5,-_fixsize.height()/3);
    //����Ѫ��
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect lifeBarBackRect(lifebarpoint,QSize(-life_bar_width,2));
    painter->drawRect(lifeBarBackRect);
    painter->setBrush(Qt::green);
    QRect lifeBarRect(lifebarpoint,QSize((double)_chp/_hp*life_bar_width,2));
    painter->drawRect(lifeBarRect);
    static const QPoint off(-_fixsize.width()/2,-_fixsize.height()/2);
    painter->translate(m_pos);
    painter->rotate(m_rotationSprite);
    painter->drawPixmap(off,m_sp);
    painter->restore();
}
void Monster::doAct(){
    _active=true;
}
void Monster::Move(){
    if(!_active)
        return;
    if(collision(m_pos,1,_despoint->pos(),1))
      {
        if(_despoint->nextTurnpoint())
        {
            m_pos=_despoint->pos();
            _despoint=_despoint->nextTurnpoint();
        }
        else
        {
            _game->gethurt();
            _game->removemon(this);
            return;
        }
      }
    QPoint targetPoint=_despoint->pos();
    double movementSpeed=_speed;
    QVector2D normalized(targetPoint-m_pos);
    normalized.normalize();
    m_pos=m_pos+normalized.toPoint()*movementSpeed;
    m_rotationSprite=qRadiansToDegrees(qAtan2(normalized.y(),normalized.x()))+180;
}
void Monster::disappear(){
    if(m_attackedTowersList.empty())
        return;
    foreach(Attacktower* attacker,m_attackedTowersList)
        attacker->killed();
    _game->removemon(this);
}
void Monster::getdamaged(int damage){
    _chp-=damage;
    if(_chp<=0)
    {
        _game->getmonney(150);
        disappear();

    }
}
void Monster::getattacked(Attacktower *attacker){
    m_attackedTowersList.push_back(attacker);
}
void Monster::lost(Attacktower *attacker){
    m_attackedTowersList.removeOne(attacker);
}
QPoint Monster::pos() const
{
    return m_pos;
}


