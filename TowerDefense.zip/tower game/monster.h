#ifndef MONSTER_H
#define MONSTER_H
#include<QPoint>
#include<QPixmap>
#include<QObject>
#include<QPainter>
#include<QTimer>
#include<QSize>
#include <QColor>
#include <QDebug>
#include <QMatrix>
#include <QVector2D>
#include <QtMath>
#include"turnpoint.h"
#include"mw1.h"
#include"use.h"

class MW1;
class Turnpoint;
class QPainter;
class Attacktower;

class Monster:public QObject{
    Q_OBJECT

public:
    Monster(Turnpoint *beginpos,MW1 *game,const QPixmap &s=QPixmap(":/pics/monster(1).png"));
    ~Monster();
    void draw(QPainter *painter)const;
    void Move();
    void getdamaged(int damage);
    void disappear();
    void getattacked(Attacktower  *attacker);
    void lost(Attacktower  *attacker);
    QPoint pos() const;

protected:
    const int  _hp=40;//�������ֵ
    int  _chp;//��ǰ����ֵ
    bool  _active;
    QPoint  m_pos;
    const QPixmap  m_sp;
    Turnpoint  *_despoint;
    MW1  *_game;
    qreal  m_rotationSprite;
    qreal  _speed;
    QList<Attacktower *>  m_attackedTowersList;
    static const QSize  _fixsize;

public slots:
    void doAct();

};
#endif // MONSTER_H
