#include"turnpoint.h"
#include<QPoint>
#include<QPainter>
#include<QColor>

Turnpoint::Turnpoint(QPoint pos):_pos(pos),_nextTurnpoint(NULL){

}
void Turnpoint::nextPoint(Turnpoint *nextpoint){
    _nextTurnpoint=nextpoint;
}
Turnpoint* Turnpoint::nextTurnpoint() const{
    return _nextTurnpoint;
}
const QPoint Turnpoint::pos() const{
    return _pos;
}
void Turnpoint::draw(QPainter *p) const{
    p->save();
    p->setPen(QColor(0,255,0));
    p->drawEllipse(_pos,6,6);
    p->drawEllipse(_pos,2,2);

    if(_nextTurnpoint)
        p->drawLine(_pos,_nextTurnpoint->_pos);
    p->restore();
}
