#ifndef TURNPOINT_H
#define TURNPOINT_H
#include<QPoint>
#include<QPainter>
class Monster;
class MW1;
class Towerset;
class Turnpoint{
public:
    Turnpoint(QPoint pos);//���캯��
    void nextPoint(Turnpoint *nextpoint);//������һ���ƶ��յ�
    Turnpoint* nextTurnpoint()const;
    const QPoint pos()const;
    void draw(QPainter *p)const;
private:
    QPoint _pos;
    Turnpoint *_nextTurnpoint;
};
#endif // TURNPOINT_H
