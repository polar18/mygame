#ifndef USE_H
#define USE_H
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include <QtMath>


inline bool collision(QPoint p1,int r1,QPoint p2,int r2){
    const int xdif=p1.x()-p2.x();
    const int ydif=p1.y()-p2.y();
    const double distance=sqrt(xdif*xdif+ydif*ydif);
    if(distance<=r1+r2)
        return true;
    return false;
}
#endif // USE_H
