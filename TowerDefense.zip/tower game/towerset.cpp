#include"towerset.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>

const QSize Towerset::_fixsize(44,44);

Towerset::Towerset(QPoint pos,const QPixmap &s):_pos(pos),_hastower(false),_s(s){

}
const QPoint Towerset::cPos() const{
    QPoint offsetPoint(_fixsize.width()/2,_fixsize.height()/2);
    return _pos+offsetPoint;
}
bool Towerset::hasPoint(const QPoint &pos) const{
    bool x=_pos.x()<pos.x()&&pos.x()<(_pos.x()+_fixsize.width());
    bool y=_pos.y()<pos.y()&&pos.y()<(_pos.y()+_fixsize.height());
    return x&&y;
}
bool Towerset::hastower() const{
    return _hastower;
}

void Towerset::settower(bool hastower){
    _hastower=hastower;
}
void Towerset::draw(QPainter *painter) const{
    painter->drawPixmap(_pos.x(),_pos.y(),_s);
}
