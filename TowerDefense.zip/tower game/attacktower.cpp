#include"attacktower.h"
#include"towerset.h"
#include"monster.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>
const QSize Attacktower::m_fixsize(44,44);

Attacktower::Attacktower(QPoint pos,MW1* game,const QPixmap &s)
    :m_attacking(false)
    ,m_rotationSprite(0.0)
    ,m_chooseEnemy(NULL)
    ,m_game(game)
    ,m_pos(pos)
    ,m_s(s){

    m_fireTimer=new QTimer(this);
    connect(m_fireTimer,SIGNAL(timeout()),this,SLOT(shootWeapon()));
}

Attacktower::~Attacktower(){
    delete m_fireTimer;
    m_fireTimer=NULL;
}

void Attacktower::draw(QPainter *painter)const{
    painter->save();
    painter->setPen(Qt::white);
    painter->drawEllipse(m_pos,m_range,m_range);
    static const QPoint offsetPoint(-m_fixsize.width()/2,-m_fixsize.height()/2);
    painter->translate(m_pos);
    painter->drawPixmap(offsetPoint,m_s);
    painter->restore();
}

void Attacktower::checkmonster(){
    if(m_chooseEnemy)
    {
        QVector2D normalized(m_chooseEnemy->pos()-m_pos);
        normalized.normalize();
        m_rotationSprite=qRadiansToDegrees(qAtan2(normalized.y(),normalized.x()))-90;
    }
    else
    {
        QList<Monster*>monsterlist=m_game->monsterlist();
        foreach(Monster* monster,monsterlist)
        {
            if(collision(m_pos,m_range,monster->pos(),1))
            {
                choosemonster(monster);
                break;
            }
        }
    }
}

void Attacktower::attackenemy(){
    m_fireTimer->start(m_rate);
}
void Attacktower::choosemonster(Monster *monster){
    m_chooseEnemy=monster;
    attackenemy();
    m_chooseEnemy->getattacked(this);
}
void Attacktower::shootWeapon(){
    Bullet* bullet=new Bullet(m_pos,m_chooseEnemy->pos(),m_hurt,m_chooseEnemy,m_game);
    bullet->move();
    m_game->addbullet(bullet);
}
void Attacktower::killed(){
    if(m_chooseEnemy)
        m_chooseEnemy=NULL;
    m_fireTimer->stop();
    m_rotationSprite=0.0;
}
void Attacktower::lostenemy(){
    m_chooseEnemy->disappear();
    if(m_chooseEnemy)
        m_chooseEnemy=NULL;
    m_fireTimer->stop();
    m_rotationSprite=0.0;
}
