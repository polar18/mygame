#include"bullet.h"
#include"monster.h"
#include"attacktower.h"
#include"mw1.h"
#include"use.h"
#include <QPainter>
#include <QPropertyAnimation>

const QSize Bullet::m_fixedsize(5, 5);

Bullet::Bullet(QPoint startpoint,QPoint targetpoint,int hurt,Monster*  monster,MW1*  game,const QPixmap &sprite)
    : m_startpoint(startpoint)
    , m_targetpoint(targetpoint)
    , m_sprite(sprite)
    , nowpoint(startpoint)
    , m_monster(monster)
    , m_game(game)
    , m_hurt(hurt)
      {

}

void Bullet::setnowpos(QPoint pos){
    nowpoint=pos;
}

QPoint Bullet::nowpos() const{
    return nowpoint;
}

void Bullet::draw(QPainter *painter) const{
    painter->drawPixmap(nowpoint,m_sprite);
}

void Bullet::move(){
    QPropertyAnimation* animation=new QPropertyAnimation(this,"nowpoint");
    animation->setDuration(50);
    animation->setStartValue(m_startpoint);
    animation->setEndValue(m_targetpoint);
    connect(animation,SIGNAL(finished()),this,SLOT(hitenemy()));
    animation->start();
}

void Bullet::hitenemy(){
    if(m_game->monsterlist().indexOf(m_monster)!=-1)
        m_monster->getdamaged(m_hurt);
    m_game->removebullet(this);
}


