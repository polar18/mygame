#include"use.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include<math.h>

inline bool use::collision(QPoint p1, int r1, QPoint p2, int r2){
    const int xdif=p1.x()-p2.x();
    const int ydif=p1.y()-p2.y();
    const double dis=sqrt(xdif*xdif+ydif*ydif);
    if(dis<=r1+r2)
        return true;
    else
        return false;
}
